
package com.example.uoltransportdesk_70147272;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.uoltransportdesk_70147272.R;

public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_NAME =
            "com.example.uoltransportdesk.EXTRA_NAME";

    private EditText etName;
    private Button btnPage;
    private Button btnCallOffice;
    private Button btnBusStop;
    private Button btnReport;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        btnPage = findViewById(R.id.btnPage);
        btnCallOffice = findViewById(R.id.btnCallOffice);
        btnBusStop = findViewById(R.id.btnBusStop);
        btnReport = findViewById(R.id.btnReport);


        btnPage.setOnClickListener(v -> {
            Intent intent = new Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://www.uol.edu.pk")
            );

            openIntent(this, intent);
        });


        btnCallOffice.setOnClickListener(v -> {
            Intent intent = new Intent(
                    Intent.ACTION_DIAL,
                    Uri.parse("tel:04298765432")
            );

            openIntent(this, intent);
        });

        btnBusStop.setOnClickListener(v -> {
            Intent intent = new Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse(
                            "geo:0,0?q=Thokar+Niaz+Baig,+Lahore"
                    )
            );

            openIntent(this, intent);
        });


        btnReport.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();

            if (name.isEmpty()) {
                etName.setError("Please enter your name");
                etName.requestFocus();
                return;
            }

            Intent intent = new Intent(
                    MainActivity.this,
                    ProblemActivity.class
            );

            intent.putExtra(EXTRA_NAME, name);
            startActivity(intent);
        });
    }


    public static void openIntent(Context context, Intent intent) {
        try {
            context.startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(
                    context,
                    "No app found for this action",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }
}
