
package com.example.uoltransportdesk_70147272;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.uoltransportdesk_70147272.MainActivity;
import com.example.uoltransportdesk_70147272.R;

public class ProblemActivity extends AppCompatActivity {

    private TextView tvGreeting;
    private EditText etPhone;
    private EditText etEmail;
    private Button btnCallDriver;
    private Button btnSendEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_problem);

        tvGreeting = findViewById(R.id.tvGreeting);
        etPhone = findViewById(R.id.etPhone);
        etEmail = findViewById(R.id.etEmail);
        btnCallDriver = findViewById(R.id.btnCallDriver);
        btnSendEmail = findViewById(R.id.btnSendEmail);

        // Receive the student's name
        String name = getIntent().getStringExtra(
                MainActivity.EXTRA_NAME
        );

        if (name == null || name.trim().isEmpty()) {
            name = "Student";
        }

        tvGreeting.setText(
                "Hello, " + name + "! Tell us what went wrong."
        );

        // Validate the driver's phone number
        btnCallDriver.setOnClickListener(v -> {
            String phone = etPhone.getText().toString().trim();

            if (!phone.matches("^03[0-9]{9}$")) {
                etPhone.setError(
                        "Enter an 11-digit number starting with 03"
                );
                etPhone.requestFocus();
                return;
            }

            Intent intent = new Intent(
                    Intent.ACTION_DIAL,
                    Uri.parse("tel:" + phone)
            );

            MainActivity.openIntent(this, intent);
        });

        // Validate the email address
        btnSendEmail.setOnClickListener(v -> {
            String email = etEmail.getText().toString().trim();

            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                etEmail.setError(
                        "Please enter a valid email address"
                );
                etEmail.requestFocus();
                return;
            }

            Intent intent = new Intent(
                    Intent.ACTION_SENDTO,
                    Uri.parse("mailto:" + email)
            );

            MainActivity.openIntent(this, intent);
        });
    }
}
